from setuptools import setup
setup(
    name="autos",
    version="1.0",
    description="Todo lo relacionado con autos",
    author="Valeria Hernandez",
    author_email="valhdl7@gmail.com",
    packages=["autos"]
)